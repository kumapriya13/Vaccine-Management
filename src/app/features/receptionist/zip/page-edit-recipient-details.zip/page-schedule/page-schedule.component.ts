import { Component, OnInit } from '@angular/core';
import { ReceptionistService } from '../receptionist.service';

@Component({
  selector: 'app-page-schedule',
  templateUrl: './page-schedule.component.html',
  styleUrls: ['./page-schedule.component.scss']
})
export class PageScheduleComponent implements OnInit {
  todayDate = new Date();
  selectedOption: string = '';
  receptionistDetails: any = {}; 
  constructor(private receptionistService: ReceptionistService) { }
  visits: any[] = [];
  visitsReponse: any = {};
  searchText: string = '';

  // response List Array
  checkedInResponse: any = null;
  completedResponse: any = null;
  initiatedResponse: any = null;
  missedResponse: any = null;
  observationResponse: any = null;
  upcomingResponse: any = null;

  // response List Array
  checkedInList: any = [];
  completedList: any = [];
  initiatedList: any = [];
  missedList: any = [];
  observationList: any = [];
  upcomingList: any = [];
  currentVisitRow: any = {};
  ngOnInit(): void {
    this.receptionistDetails = this.receptionistService.localStorage_getReceptionistInfo();
    console.log(this.receptionistDetails);
    if (!this.receptionistDetails) {
      this.receptionistService.getReceptionistInfo().subscribe(
        (res: any) => {
          this.receptionistDetails = res;
          console.log(res);
        },
        (err) => {
          console.log(err)
        }
      );
    }

    this.receptionistService.getReceptionistVisits().subscribe(
      (res: any) => {
        this.checkedInResponse = res.checkedIn;
        this.completedResponse = res.completed;
        this.initiatedResponse = res.initiated;
        this.missedResponse = res.missed;
        this.observationResponse = res.observation;
        this.upcomingResponse = res.upcoming;

        this.checkedInList = this.checkedInResponse.results ? this.checkedInResponse.results : [];
        this.completedList = this.completedResponse.results ? this.completedResponse.results : [];
        this.initiatedList = this.initiatedResponse.results ? this.initiatedResponse.results : [];
        this.missedList = this.missedResponse.results ? this.missedResponse.results : [];
        this.observationList = this.observationResponse.results ? this.observationResponse.results : [];
        this.upcomingList = this.upcomingResponse.results ? this.upcomingResponse.results : [];

        this.checkedInList.push( ...this.upcomingList );

        console.log(this.checkedInList);
      },
      (err) => {
        console.log(err)
      }
    );
  }

  setVisitRowToLocalStorage(visitRow: any) {
    this.currentVisitRow = visitRow;
    window.localStorage.setItem('receptionist-visit', JSON.stringify(visitRow));
  }
}