import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms'
import { Router,ActivatedRoute } from '@angular/router';
import { first, map, min } from 'rxjs/operators'; 
import { v4 as uuidv4 } from 'uuid';
import { Observable, of } from 'rxjs';
import { MatCheckbox, MatCheckboxChange } from '@angular/material/checkbox';
import { applicableList, raceList } from '../../../shared/helpers/constant';
import { ProviderRecipientAuthService } from '../../../shared/providers/provider-recipient-auth.service';
//import { UserService } from '../providers/user.service';
import { CountriesService } from 'src/app/shared/services/countries.service';
import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/shared/helpers/dd-mm-yyyy-formater';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { UserService } from '../../recipient/providers/user.service';
import { ReceptionistService } from '../receptionist.service';

@Component({
  selector: 'app-page-edit-recipient-details',
  templateUrl: './page-edit-recipient-details.component.html',
  styleUrls: ['./page-edit-recipient-details.component.scss']
})
export class PageEditRecipientDetailsComponent implements OnInit {
  dialCode: string;
  passwordToggler: boolean;
  returnUrl: string;
  authRecipientEditForm: FormGroup;
  raceList: any[] = raceList;
  stateInfo: any[] = [];
  countryInfo: any[] = [];
  cityInfo: any[] = [];
  applicableList: any[] = applicableList;
  userDetails: any = {};
  public show:boolean = false;
  public stateshow: boolean = true;

  countyAd = [
    "Atlantic",
    "Bergen",
    "Burlington",
    "Camden",
    "Cumberland",
   "Essex",
   "Glouceste", 
   "Hudson", 
   "Hunterdon",
    "Mercer",
    "Middlesex",
    "Monmouth", 
    "Morris",
    "Ocean",
    "Passaic", 
    "Salem", 
    "Somerset", 
    "Sussex", 
    "Union", 
    "Warren" 
    ];
  constructor(
    private userService: UserService,
    private _formBuilder: FormBuilder,
    private _router: Router,
    private activatedRoute: ActivatedRoute,
    private _providerRecipientAuthService: ProviderRecipientAuthService,
    private country:CountriesService,
    private _superAdminService:ReceptionistService,
    
    
  ) { }

  ngOnInit(): void {
    this.buildForm();
    this.setFormControlValue();
    this.getCountries();
  }

  passwordTogglerFun() {
    this.passwordToggler = !this.passwordToggler;
  }

  onCountryChange(event) {
    this.dialCode = "+" + event.dialCode;
  }


  buildForm() {
    this.authRecipientEditForm = this._formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['',],
      phoneNumber: [''],
      dob: ['', [Validators.required]],
      address1: ['', [Validators.required]],
      address2: [''],
      address3: [''],
      city: ['', [Validators.required]],
      zip: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      state: ['', [Validators.required]],
      country: ['', [Validators.required]],
      county: ['', [Validators.required]],
      insurance: [''],
      insuranceprovidername: [''],
      medicalGroupNumber: [''],
      memberId: [''],
    });
  }

  setFormControlValue() {
    const reqData = {
      "q": "id=" + this.activatedRoute.snapshot.params['id'],
      "page": 1,
      "pageLength": 10,
      "sort": ""
    };
      this._superAdminService.getRecepientData(reqData).subscribe(
      (res) => {
        console.log(res.results);
    const currentRecipientProfile = res.results;
    console.log(currentRecipientProfile);
    const answers = currentRecipientProfile.static_questionnaire_answers;
    if (!!answers && answers.length > 0) {
      var Insurance = answers.find(x => x.question_text.trim() === 'Insurance');
      var insuranceprovidername = answers.find(x => x.question_text.trim() === 'Insurance Provider Name');
      var medicalGroupNumber = answers.find(x => x.question_text.trim() === 'Medical Group Number');
      var memberId = answers.find(x => x.question_text.trim() === 'Medical ID');
    }
    this.authRecipientEditForm.setValue({
      firstName: currentRecipientProfile.fname ? currentRecipientProfile.fname : '',
      lastName: currentRecipientProfile.lname ? currentRecipientProfile.lname : '',
      email: currentRecipientProfile.email ? currentRecipientProfile.email : '',
      phoneNumber: currentRecipientProfile.mobile_number ? currentRecipientProfile.mobile_number : '',
      dob: currentRecipientProfile.dob ? new Date(currentRecipientProfile.dob) : '',
      address1: currentRecipientProfile.address1 ? currentRecipientProfile.address1 : '',
      address2: currentRecipientProfile.address2 ? currentRecipientProfile.address2 : '',
      address3: currentRecipientProfile.address3 ? currentRecipientProfile.address3 : '',
      zip: currentRecipientProfile.zip ? currentRecipientProfile.zip : '',
      city: currentRecipientProfile.city ? currentRecipientProfile.city : '',
      state: currentRecipientProfile.state ? currentRecipientProfile.state : '',
      country: currentRecipientProfile.country ? currentRecipientProfile.country : '',
      county: currentRecipientProfile.county ? currentRecipientProfile.county : '',
      insurance: Insurance ? Insurance.answers[0] : '',
      insuranceprovidername: insuranceprovidername ? insuranceprovidername.answers[0] : '',
      medicalGroupNumber: medicalGroupNumber ? medicalGroupNumber.answers[0] : '',
      memberId: memberId ? memberId.answers[0] : '',
    })
   
  })
}


  authRecipientEditFormSub() {
    if (!this.authRecipientEditForm.valid) {
      return;
    }

    let formData = this.authRecipientEditForm.value;
    const currentRecipientProfile = JSON.parse(localStorage.getItem('recipientProfile'));
    currentRecipientProfile.fname = formData.firstName
    currentRecipientProfile.lname = formData.lastName
    currentRecipientProfile.email = formData.email
    // currentRecipientProfile.mobile_number = formData.phoneNumber;
    currentRecipientProfile.dob = formData.dob;
    currentRecipientProfile.address1 = formData.address1;
    currentRecipientProfile.address2 = formData.address2;
    currentRecipientProfile.address3 = formData.address3;
    currentRecipientProfile.zip = formData.zip;
    currentRecipientProfile.city = formData.city;
    currentRecipientProfile.state = formData.state;
    currentRecipientProfile.country = formData.country;
    currentRecipientProfile.county = formData.county;


    const answers: any[] = currentRecipientProfile.static_questionnaire_answers || [];
    if (!!answers && answers.length > 0) {
      var Insurance = answers.find(x => x.question_text.trim() === 'Insurance');
      var insuranceprovidername = answers.find(x => x.question_text.trim() === 'Insurance Provider Name');
      var medicalGroupNumber = answers.find(x => x.question_text.trim() === 'Medical Group Number');
      var memberId = answers.find(x => x.question_text.trim() === 'Medical ID');
     
    }

    /**
     * Updating Insurance answers
     */
    if (Insurance)
      Insurance.answers[0] = Insurance ? formData.insurance : '';
    if (insuranceprovidername)
      insuranceprovidername.answers[0] = insuranceprovidername ? formData.insuranceprovidername : '';
    if (medicalGroupNumber)
      medicalGroupNumber.answers[0] = medicalGroupNumber ? formData.medicalGroupNumber : '';
    if (memberId)
      memberId.answers[0] = memberId ? formData.memberId : '';

    /**
     * Updating questing if not there
     */

    if (!Insurance) {
      const Insurance = {
        questioneer_id: "1",
        question_text: "Insurance",
        answers: [formData.insurance]
      }
      answers.push(Insurance);
    }
    if (!insuranceprovidername) {
      const providerName = {
        questioneer_id: "2",
        question_text: "Insurance Provider Name",
        answers: [formData.insuranceprovidername]
      }
      answers.push(providerName)
    }
    if (!medicalGroupNumber) {
      const mGroupName = {
        questioneer_id: "3",
        question_text: "Medical Group Number",
        answers: [formData.medicalGroupNumber]
      }
      answers.push(mGroupName)
    }
    if (!memberId) {
      const mId = {
        questioneer_id: "4",
        question_text: "Medical ID",
        answers: [formData.memberId]
      }
      answers.push(mId);
    }

    console.log(currentRecipientProfile);

    this.userService.saveRecipientProfile(currentRecipientProfile).subscribe(
      res => {
        this._router.navigate(['/receptionist/schedule']);
      },
      err => {
        console.log(err); 
      }
    );
  }

  checkUserByEmailID(emailControl: FormControl): Observable<any> {
    const emailId = emailControl.value;
    return this._providerRecipientAuthService.userCheck(emailId)
      .pipe(
        map(existingRecipient => {
          if (existingRecipient) {
            return { existingRecipient: true }
          } else {
            return null;
          }
        })
      );
  }

  onRaceCheckboxChange(value: string, isChecked: boolean) {
    const raceFormArray = <FormArray>(<FormGroup>this.authRecipientEditForm.controls.answers).controls.raceFormArray;
    if (isChecked) {
      raceFormArray.push(new FormControl(value));
    } else {
      let index = raceFormArray.controls.findIndex(x => x.value == value)
      raceFormArray.removeAt(index);
    }
  }

  getCountries(){
    this.country.allCountries().
    subscribe(
      data2 => {
        this.countryInfo=data2.Countries;
       // console.log(this.countryInfo['230'].States);
       // this.stateInfo=this.countryInfo['230'].States;
        //console.log('Data:', this.countryInfo);
      },
      err => console.log(err),
      () => console.log('complete')
    )
  }

  onChangeCountry(countryValues) {
    console.log(countryValues);
    let countryValue= countryValues.value;
    console.log(this.countryInfo);
  }

  onChangeState(stateValues) {
    let stateValue=stateValues.value;
    this.cityInfo=this.stateInfo[stateValue].Cities;
    //console.log(this.cityInfo);
  }

  onSelectAllCheckboxChange(value: string, isChecked: boolean) {
    const applyAllFormArray = <FormArray>(<FormGroup>this.authRecipientEditForm.controls.answers).controls.applyAllFormArray;

    if (isChecked) {
      applyAllFormArray.push(new FormControl(value));
    } else {
      let index = applyAllFormArray.controls.findIndex(x => x.value == value)
      applyAllFormArray.removeAt(index);
    }
  }

  fetcheditzipdetails(zipvalue){
    let zip={
      "zip": zipvalue.value
  }
  
    this._providerRecipientAuthService.fetchdetails(zip).
    subscribe(
      (res) =>{
        this.authRecipientEditForm.controls.city.setValue(res.city);
        this.authRecipientEditForm.controls.state.setValue(res.state);
        this.show=true;
        this.stateshow=false
      },
      err => {
        this.show=false;
   this.stateshow=true
        //this._NotificationService.showNotification("User already exist","top",'error')
        console.log(err);
         //alert(err)
       }
    )
  }
}
