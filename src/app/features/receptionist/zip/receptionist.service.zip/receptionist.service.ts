import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReceptionistService {
  private apiUrl = environment.apiUrl;
  private ssoUrL = environment.sso_url;
  receptionist: any = {};
  public _userProfile: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(
    private _http: HttpClient,
    private _router: Router
  ) { }

  localStorage_getReceptionistInfo() {
    let vacUser = localStorage.getItem('receptionist_admin-user');
    return JSON.parse(vacUser);
  }

  getReceptionistInfo() {
    this.receptionist = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    let url = `${this.apiUrl}vaccinator/item`;
    let header = new HttpHeaders();
    let reqData = { id: this.receptionist.user_id };
    header = header.set('Authorization', 'Bearer ' + this.receptionist.jwt);
    return this._http
      .post<any>(url, reqData, { headers: header })
      .pipe(
        map((response) => {
          this._userProfile.next(response);
          localStorage.setItem('receptionist_admin-user', JSON.stringify(response));
          return response;
        })
      );
  }

  getReceptionistVisits() {
    this.receptionist = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    
    let dateObj = new Date();
    let year = dateObj.getFullYear();
    let month: any = dateObj.getMonth() + 1;
    let date: any = dateObj.getDate();

    month = month.toLocaleString('en-US', {
      minimumIntegerDigits: 2,
      useGrouping: false,
    });
    date = date.toLocaleString('en-US', {
      minimumIntegerDigits: 2,
      useGrouping: false,
    });
    console.clear();
    console.log(this.receptionist);
    let reqData = {
      siteId: this.receptionist.site_ids[0],
      // "siteId": "38a61197-07a0-40a8-b618-ab6c3519ee98",
      // "startDate": "2021-02-18",
      // "endDate": "2021-02-18",
      startDate: String(year + '-' + month + '-' + date),
      endDate: String(year + '-' + month + '-' + date),
    };
    let url = `${this.apiUrl}vaccinator/visits`;
    let header = new HttpHeaders();
    header = header.set('Authorization', 'Bearer ' + this.receptionist.jwt);
    return this._http.post<any>(url, reqData, { headers: header });
  }

  getchecklist(visitId: string): Observable<any[]> {
    this.receptionist = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    const url = `${this.apiUrl}visit/checklist/get`;
    const checkListReq = { visitId: visitId };
    let header = new HttpHeaders();
    header = header.set('Authorization', 'Bearer ' + this.receptionist.jwt);
    return this._http
      .post<any>(url, checkListReq, { headers: header })
      .pipe(map((res) => res.checklist));
  }

  saveAnswerList(reqData): Observable<any> {
    this.receptionist = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    let header = new HttpHeaders();
    header = header.set('Authorization', 'Bearer ' + this.receptionist.jwt);
    const url = `${this.apiUrl}visit/checklist/save`;
    return this._http.post<any>(url, reqData, { headers: header });
  }

  getMaterialList(): Observable<any> {
    this.receptionist = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    let reqObj = {
      site_id: this.receptionist.site_ids[0],
    };
                  
    let header = new HttpHeaders();
    header = header.set('Authorization', 'Bearer ' + this.receptionist.jwt);
    const url = `${this.apiUrl}materialBatch/list`;
    return this._http.post<any>(url, reqObj, { headers: header });
  }

  visitUpdateAdminstrationDetails(reqData: any = {}) {
    this.receptionist = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    let header = new HttpHeaders();
    header = header.set('Authorization', 'Bearer ' + this.receptionist.jwt);
    reqData['vaccinator'] = this.receptionist.user_id;
    const url = `${this.apiUrl}visit/updateAdminstrationDetails`;
    return this._http.post<any>(url, reqData, { headers: header });
  }

  //receptionist_admin-token
  sitesearchbyZipId(zipId: number): Observable<any> {
    const url = `${this.apiUrl}site/searchbyZipId`;
    const reqBody: object = { zip: zipId };
    return this._http.post<any>(url, reqBody).pipe(
      map(x => {
        return x.Response;
      })
    );

  }

  getStaticDataAppointment() {
    const url = `${this.apiUrl}receptionist/visits`;
    let header = new HttpHeaders();
    const receptionsist = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    const reqObj: object = {
      "siteId": receptionsist.site_ids[0],
      "startDate": "2021-03-12",
      "endDate": "2021-02-12",
      "currentTime": "2021-02-12T13:22:00"
    };
    const siteadminInfo = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    header = header.set('Authorization', 'Bearer ' + siteadminInfo.jwt);
    return this._http.post<any>(url, reqObj, { headers: header });
  }

  getRecepientData(reqobj: any) {
    const url = `${this.apiUrl}manage/recipient/search`;
    let header = new HttpHeaders();
    const siteadminInfo = JSON.parse(localStorage.getItem('receptionist_admin-token'));
    header = header.set('Authorization', 'Bearer ' + siteadminInfo.jwt);
    return this._http.post<any>(url, reqobj, { headers: header });

  }


}




